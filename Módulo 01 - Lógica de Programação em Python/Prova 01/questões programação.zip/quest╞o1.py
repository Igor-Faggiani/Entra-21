"""
 Escrever um programa que calcule o Índice de Massa Corporal (IMC) com base no peso e altura inseridos pelo usuário.
 Em seguida, o programa deve fornecer uma classificação de acordo com o resultado do cálculo do IMC.
"""

# Atribuindo variáveis:
nome = input('Digite o seu nome: ')
peso = float(input('Digite o seu peso em (kg): '))
altura = float(input('Digite a sua altura em (M): '))

# Calculo do IMC:
calculo_imc = peso / altura**2

#Saída de dados:
print(f'Sr(a) {nome}, seu Indice de Massa Corporal (IMC) é de: {calculo_imc:.2f}')

#Calculando a classificação:
if calculo_imc <= 18.5:
    print('IMC menor que 18.5: Você está abaixo do peso!')
elif calculo_imc >= 18.5 and calculo_imc <= 24.9:
    print('IMC entre 18.5 e 24.9: Você está no peso ideal!')
elif calculo_imc >= 25 and calculo_imc <= 29.9:
    print('IMC entre 25 e 29.9: Você está com Sobrepeso!')
elif calculo_imc >= 30 and calculo_imc <= 34.9:
    print('IMC entre 30 e 34.9: Você está com Obesidade grau 1!')
elif calculo_imc >= 35 and calculo_imc <= 39.9:
    print('IMC entre 35 e 39.9: Você está com Obesidade grau 2!')
elif calculo_imc >= 40:
    print('Você está com Obesidade grau 3!')