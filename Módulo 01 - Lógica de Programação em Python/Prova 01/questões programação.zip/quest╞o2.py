"""Faça um algoritmo que simule uma calculadora. Para isso, o algoritmo deverá solicitar a
operação matemática que deve ser executada e os números necessários para cada operação.
O algoritmo deve permitir as operações de adição, subtração, multiplicação, divisão, porcentagem
(ex.: 20% de 100 = 20) e logaritmo (ex.: log636 = 2).
"""
from math import log

# Atribuindo Variáveis:
numero1 = float(input('Digite um número: '))
operacao = input('Digite a operação que você deseja: (+) soma, (-) subtração, (/) divisão, (*) multiplicação, (%) porcentagem e (log) logaritmo: ')
numero2 = float(input('Digite outro número: '))

#Calculos:

soma = numero1 + numero2
subtracao = numero1 - numero2
divisao = numero1 / numero2
multiplicacao = numero1 * numero2
porcentagem = numero1 * (numero2/100)
logaritmo = log(numero2, numero1)


if operacao == "+":
    print(f'A soma é: {soma:.2f}')
elif operacao == "-":
    print(f'A subtração é de: {subtracao:.2f}')
elif operacao == "/":
    print(f'A divisão é de: {divisao:.2f}')
elif operacao == "*":
    print(f'A multiplicação é de: {multiplicacao:.2f}')
elif operacao == "%":
    print(f'A porcentagem é de: {porcentagem:.2f}%')
elif operacao == "log":
    print(f'O log de {numero2} com base {numero1} é de: {logaritmo:.2f}')
else:
    print('Operação Inválida!')
