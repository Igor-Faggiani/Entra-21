"""
Faça um fluxograma que representa um algoritmo que leia um ano e verifique se ele é bissexto.
"""

# Atribuindo variáveis:

ano = int(input('Digite o ano para saber se é bissexto: '))

#Calculos:

if (ano % 4 == 0 and ano % 100 != 0) or (ano % 400 == 0):
    print(f'O ano {ano} é bissexto (tem 366 dias)')
else:
    print(f'O ano {ano} não é bissexto (tem 365 dias)')
