"""

4) Uma empresa deseja calcular o bônus salarial de seus funcionários com base no desempenho deles ao longo do ano.
O bônus é calculado da seguinte forma:

Se o funcionário atingir todas as metas de vendas, o bônus é de 20% do salário anual.
Se o funcionário atingir pelo menos metade das metas de vendas, o bônus é de 10% do salário anual.
Caso contrário, o funcionário não receberá bônus.

Escreva um que solicite ao usuário o salário mensal, o valor das metas de desempenho atingidas pelo funcionário
e o valor total das metas de venda do funcionário. Com base nas regras acima,
o programa deve calcular e exibir o valor do bônus que o funcionário receberá.
"""

# Solicitar os dados:
salario_mensal = float(input('Digite seu salário mensal em Reais (R$): '))
valor_metas_atingidas = float(input('Digite o Valor das metas atingidas em Reais (R$): '))
valor_metas_total = float(input('Digite o Valor total das metas a serem atingidas em Reais (R$): '))

# Convertendo o salário mensal para anual:
salario_anual = salario_mensal * 12

# Agora utilizar o if para saber se atingiu ou não as metas:
if valor_metas_atingidas == valor_metas_total:
    #Calcular 20% do salário anual e somar:
    print(f'Você terá um aumento de 20% no seu salário anual e receberá: R${salario_anual + salario_anual * 20/100:,}!')
elif valor_metas_atingidas == valor_metas_total * 50/100:
    #Calcular 10% do salário anual e somar:
    print(f'Você terá um aumento de 10% no seu salário anual e receberá: R${salario_anual + salario_anual * 10/100:,}!')
else:
    print('Você não bateu as metas, por tanto não receberá o bônus!')