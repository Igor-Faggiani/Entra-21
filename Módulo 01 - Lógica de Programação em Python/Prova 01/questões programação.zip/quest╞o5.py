"""
Questão Número 5:
"""

# Solicitar os dados:

valor_reais = int(input('Digite seu salário em Reais (R$): '))
resto_valor = valor_reais

#Calculando a quantidade de notas de R$200,00:
quantidade_notas_200 = resto_valor // 200
resto_valor -= quantidade_notas_200 * 200

#Calculando a quantidade de notas de R$100,00:
quantidade_notas_100 = resto_valor // 100
resto_valor -= quantidade_notas_100 * 100

#Calculando a quantidade de notas de R$50,00:
quantidade_notas_50 = resto_valor // 50
resto_valor -= quantidade_notas_50 * 50

#Calculando a quantidade de notas de R$20,00:
quantidade_notas_20 = resto_valor // 20
resto_valor -= quantidade_notas_20 * 20

#Calculando a quantidade de notas de R$10,00:
quantidade_notas_10 = resto_valor // 10
resto_valor -= quantidade_notas_10 * 10

#Calculando a quantidade de notas de R$5,00:
quantidade_notas_5 = resto_valor // 5
resto_valor -= quantidade_notas_5 * 5

#Calculando a quantidade de notas de R$2,00:
quantidade_notas_2 = resto_valor // 2
resto_valor -= quantidade_notas_2 * 2

#Calculando a quantidade de moedas de R$ 1::
quantidade_moedas_1 = resto_valor // 1

print(f"""
Notas de R$ 200,00: {quantidade_notas_200}!
Notas de R$ 100,00: {quantidade_notas_100}!
Notas de R$ 50,00: {quantidade_notas_50}!
Notas de R$ 20,00: {quantidade_notas_20}!
Notas de R$ 10,00: {quantidade_notas_10}!
Notas de R$ 5,00: {quantidade_notas_5}!
Notas de R$ 2,00: {quantidade_notas_2}!
Moedas de R$ 1,00: {quantidade_moedas_1}!
""")

