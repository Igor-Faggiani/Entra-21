"""
Questão número 6:

primeiro numero: o menor
segundo numero: segudo maior
terceiro numero: segundo menor
quarto numero: o maior
"""

#Solicitar os Dados:
numeros = []
for lista in range(4):
    numero = int(input("Digite um número inteiro: "))
    numeros.append(numero)

#Fução do python para ordenar os numeros:
numeros.sort()

#Exibir os números:
print(numeros[0], numeros[2], numeros[1], numeros[3])