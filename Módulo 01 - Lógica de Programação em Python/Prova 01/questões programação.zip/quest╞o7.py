"""
Questão numero 7:
"""

#Solicitar os dados:
dia = int(input('Digite um dia: '))
mes = int(input('Digite um mês: '))
ano = int(input('Digite um ano: '))

#Verificar se o mês é válido:
mes_valido = mes>= 1 and mes <=12

#Criar uma lista para o número de dias máximos por mês:
dias_meses = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

#verificar se o dia é válido:
dia_valido = dia >= 1 and dia <= dias_meses[mes]

# Verifica se a data completa é válida
if ano >= 0 and mes_valido and dia_valido:
    print("A data é válida.")
else:
    print("A data não é válida.")


